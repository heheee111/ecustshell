#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50];
    char command[256];
} Alias;

Alias alias_table[100]; // 存储在 alias_table 中
int alias_count = 0;

void builtin_alias(int argc, char *argv[]) {
    if (argc == 1) {
        // 查看所有别名
        for (int i = 0; i < alias_count; i++) {
            printf("alias %s='%s'\n", alias_table[i].name, alias_table[i].command);
        }
        return;
    }
}
