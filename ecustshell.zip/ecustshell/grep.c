#define _GNU_SOURCE // 必须加在最前面，为了引入 strcasestr
#include "shell.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void builtin_grep(int argc, char *argv[]) {
    int ignore_case = 0;
    int show_line_num = 0;
    char *pattern = NULL;
    int file_idx = 0;

    // 1. 解析参数
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-i") == 0) ignore_case = 1;
        else if (strcmp(argv[i], "-n") == 0) show_line_num = 1;
        else if (!pattern) pattern = argv[i]; 
        else { file_idx = i; break; }        
    }

    if (!pattern || file_idx == 0) {
        printf("Usage: grep [-i] [-n] <pattern> <filename>\n");
        return;
    }

    FILE *fp = fopen(argv[file_idx], "r");
    if (!fp) { perror("grep"); return; }

    char line[1024];
    int line_num = 0;
    while (fgets(line, sizeof(line), fp)) {
        line_num++;
        char *match = NULL;
        if (ignore_case) {
            match = strcasestr(line, pattern); // 忽略大小写搜索
        } else {
            match = strstr(line, pattern);
        }

        if (match) {
            if (show_line_num) printf("%d:", line_num); // 输出行号
            printf("%s", line);
        }
    }
    fclose(fp);
}
