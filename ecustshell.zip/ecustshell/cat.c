#include <stdio.h>
#include <stdlib.h>

void builtin_cat(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: cat <filename1> [filename2] ...\n");
        return;
    }
    // 循环读取并输出每一个文件
    for (int i = 1; i < argc; i++) {
        FILE *fp = fopen(argv[i], "r");
        if (fp == NULL) {
            perror("cat: open file error");
            continue;
        }
        char ch;
        while ((ch = fgetc(fp)) != EOF) {
            putchar(ch);
        }
        fclose(fp);
    }
}

